# BombaArgus

The Bomba ball in the Argus look, with live screens from your wall on its panels.
The project is now plain files in `BombaArgus/` (no more zip), so you can edit
any file directly on GitHub. GitHub Actions builds the APK on every push:
Actions tab → latest run → download `Bomba-Argus-apk`.

See CONNECTING.md for how it joins the same wall as Orbit, bomba-live and OverLook.
