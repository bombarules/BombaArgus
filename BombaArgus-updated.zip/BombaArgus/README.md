# Bomba-Argus

The Bomba ball in the Argus look: your apps on a spinning soccer-ball frame in navy space,
with live screens from your devices on its open panels. Installs as its own app next to Overlook.
